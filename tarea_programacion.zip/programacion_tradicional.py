# Programa en Python - Programación Tradicional
def ingresar_temperaturas():
    print("Ingrese las temperaturas de los 7 días:")
    temperaturas = []
    for i in range(7):
        temp = float(input(f"Temperatura del día {i+1}: "))
        temperaturas.append(temp)
    return temperaturas

def calcular_promedio(temperaturas):
    return sum(temperaturas) / len(temperaturas)

def main():
    temperaturas = ingresar_temperaturas()
    promedio = calcular_promedio(temperaturas)
    print(f"Promedio semanal: {promedio:.2f} °C")

if __name__ == "__main__":
    main()
