# Comparación Programación Tradicional vs POO

Este proyecto contiene dos archivos principales:

- **programacion_tradicional.py**: Implementación usando funciones.
- **programacion_poo.py**: Implementación con Programación Orientada a Objetos.

Ambas versiones calculan el promedio semanal del clima, permitiendo observar las diferencias entre paradigmas.
