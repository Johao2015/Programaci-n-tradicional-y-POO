# Programa en Python - POO
class ClimaSemanal:
    def __init__(self):
        self.__temperaturas = []

    def ingresar_temperaturas(self):
        print("Ingrese las temperaturas de los 7 días:")
        for i in range(7):
            temp = float(input(f"Temperatura del día {i+1}: "))
            self.__temperaturas.append(temp)

    def calcular_promedio(self):
        if not self.__temperaturas:
            return 0
        return sum(self.__temperaturas) / len(self.__temperaturas)

def main():
    clima = ClimaSemanal()
    clima.ingresar_temperaturas()
    promedio = clima.calcular_promedio()
    print(f"Promedio semanal: {promedio:.2f} °C")

if __name__ == "__main__":
    main()
